import { Routes } from '@angular/router';
import { IndexComponent } from './index/index.component';
import { LoginComponent } from './login/login.component';
import { RecuperationComponent } from './recuperation/recuperation.component';
import { RegisterComponent } from './register/register.component';

export const routes: Routes = [
    {path: '', component: LoginComponent},
    {path: 'register', component: RegisterComponent},
    {path: 'recuperation', component: RecuperationComponent},
    {path: 'index', component: IndexComponent}

];
